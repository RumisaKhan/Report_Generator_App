package com.example.report_generator_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
