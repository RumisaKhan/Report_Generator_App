package com.example.report_making_app.host;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
