import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

// ignore: camel_case_types, must_be_immutable
class reportt extends StatefulWidget {
  DocumentSnapshot docid;
  reportt({super.key, required this.docid});
  @override
  // ignore: no_logic_in_create_state
  State<reportt> createState() => _reporttState(docid: docid);
}

// ignore: camel_case_types
class _reporttState extends State<reportt> {
  DocumentSnapshot docid;
  _reporttState({required this.docid});
  final pdf = pw.Document();
  // ignore: prefer_typing_uninitialized_variables
  var name;
  // ignore: prefer_typing_uninitialized_variables
  var subject1;
  // ignore: prefer_typing_uninitialized_variables
  var subject2;
  // ignore: prefer_typing_uninitialized_variables
  var subject3;

  // ignore: prefer_typing_uninitialized_variables
  var marks;
  @override
  void initState() {
    setState(() {
      name = widget.docid.get('Name');
      subject1 = widget.docid.get('MAD');
      subject2 = widget.docid.get('DSA');
      subject3 = widget.docid.get('SPM');

      marks = int.parse(subject1) + int.parse(subject2) + int.parse(subject3);
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PdfPreview(
      // maxPageWidth: 1000,
      // useActions: false,
      // canChangePageFormat: true,
      canChangeOrientation: false,
      // pageFormats:pageformat,
      canDebug: false,

      build: (format) => generateDocument(
        format,
      ),
    );
  }

  Future<Uint8List> generateDocument(PdfPageFormat format) async {
    final doc = pw.Document(pageMode: PdfPageMode.outlines);

    final font1 = await PdfGoogleFonts.openSansRegular();
    final font2 = await PdfGoogleFonts.openSansBold();
    // final image = await imageFromAssetBundle('assets/r2.svg');

    String? logo = await rootBundle.loadString('assets/r2.svg');

    doc.addPage(
      pw.Page(
        pageTheme: pw.PageTheme(
          pageFormat: format.copyWith(
            marginBottom: 0,
            marginLeft: 0,
            marginRight: 0,
            marginTop: 0,
          ),
          orientation: pw.PageOrientation.portrait,
          theme: pw.ThemeData.withFont(
            base: font1,
            bold: font2,
          ),
        ),
        build: (context) {
          return pw.Center(
              child: pw.Column(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              pw.Flexible(
                child: pw.SvgImage(
                  svg: logo,
                  height: 100,
                ),
              ),
              pw.SizedBox(
                height: 20,
              ),
              pw.Center(
                child: pw.Text(
                  'Final Report card',
                  style: const pw.TextStyle(
                    fontSize: 50,
                  ),
                ),
              ),
              pw.SizedBox(
                height: 20,
              ),
              pw.Divider(),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'Name : ',
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                  pw.Text(
                    name,
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                ],
              ),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'MAD : ',
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                  pw.Text(
                    subject1,
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                ],
              ),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'DSA : ',
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                  pw.Text(
                    subject2,
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                ],
              ),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'SPM : ',
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                  pw.Text(
                    subject3,
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                ],
              ),
              pw.Divider(),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'Total : ',
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                  pw.Text(
                    marks.toString(),
                    style: const pw.TextStyle(
                      fontSize: 50,
                    ),
                  ),
                ],
              ),
            ],
          ));
        },
      ),
    );

    return doc.save();
  }
}
